
# Inspector General Office Application

## Installation

1. Clone the repository.
2. Navigate to the project directory.
3. Run `docker-compose up` to start the application.

## Features

- User role management
- Grant servicing automation
- Quarterly report generation
- ROI analysis
- Budget optimization with AI
