
module.exports = {
  mongoURI: 'mongodb://localhost:27017/ig_office',
  jwtSecret: 'your_jwt_secret_key',
};
